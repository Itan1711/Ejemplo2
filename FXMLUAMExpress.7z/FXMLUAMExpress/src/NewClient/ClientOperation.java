
package NewClient;

import java.util.ArrayList;


public class ClientOperation {
    
    private ArrayList<Client> listClient = new ArrayList<>();    

    public ArrayList<Client> getListClient() {
        return listClient;
    }
    
    public boolean AddClient(Client client){
        return listClient.add(client);
    }
}
