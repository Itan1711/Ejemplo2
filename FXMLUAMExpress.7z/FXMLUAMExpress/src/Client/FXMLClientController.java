/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Client;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.ComboBox;

import NewClient.*;
import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.stage.Stage;


public class FXMLClientController implements Initializable {
    
    @FXML private TextField txtuserID;
    @FXML private TextField txtName;
    @FXML private TextField txtLastname;
    @FXML private TextField txtage;
    @FXML private TextField txtPhone;
    @FXML private TextField txtEmail;
    @FXML private TextField txtAddress;
    @FXML private ComboBox cmbGender;
    
    @FXML private Button btnbackMenu;

    Client client;
    ClientOperation operations = new ClientOperation();
    
    @FXML
    private void handleAddClient(ActionEvent event) {
        int id = Integer.parseInt(txtuserID.getText());
        String name = txtName.getText();
        String lastName = txtLastname.getText();
        int age = Integer.parseInt(txtage.getText());
        String telephone = txtPhone.getText();
        String email = txtEmail.getText();
        String address = txtAddress.getText();
        
        char gender;
        if(cmbGender.getValue() == "Female"){
            gender = 'f';
        } else {
            gender = 'm';
        }
      
        client = new Client(id, name, lastName, gender, age, telephone, email, address, null);
        operations.AddClient(client);
    }
    
    @FXML
    private void handleBackMenu(ActionEvent backmenu) throws IOException{
        Stage stage;
        Parent root;
        
        backmenu.getSource();
        stage=(Stage) btnbackMenu.getScene().getWindow();
        root = FXMLLoader.load(getClass().getResource("/fxmluamexpress/FXMLmainMenu"));
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    
    }    
    
}
