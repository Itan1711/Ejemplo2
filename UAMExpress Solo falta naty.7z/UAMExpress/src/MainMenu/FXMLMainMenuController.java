
package MainMenu;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;


public class FXMLMainMenuController implements Initializable {
    
    @FXML private Button btnClientMenu;
    @FXML private Button btnEmployeeMenu;
    
    public void handleSelecction(ActionEvent event) throws Exception{
    Stage stage;
    Parent root;
    
    if(event.getSource() == btnClientMenu){
        stage=(Stage) btnClientMenu.getScene().getWindow();            
        root = FXMLLoader.load(getClass().getResource("/uamexpress/UAMExpress.fxml"));
    } else{
        stage=(Stage) btnEmployeeMenu.getScene().getWindow();            
        root = FXMLLoader.load(getClass().getResource("/uamexpress/UAMExpress.fxmll"));
    }
    
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
}
    


    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
