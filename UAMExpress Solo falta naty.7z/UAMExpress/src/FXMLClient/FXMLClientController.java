
package FXMLClient;

import java.io.*;
import java.net.URL;
import java.util.Iterator;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javax.swing.JOptionPane;


public class FXMLClientController implements Initializable {

@FXML private Button btnClientMenu;
@FXML private Button btnSearch;
@FXML private TextField txt_clientID;
@FXML private TextField txtUserID;
@FXML private TextField txtName;
@FXML private TextField txtLastName;
@FXML private TextField txtAge;
@FXML private TextField txtPhone;
@FXML private TextField txtEmail;
@FXML private TextField txtAddress;
@FXML private ComboBox cmbGender;


Client client;
public ClientOperation operations = new ClientOperation();

@FXML
public void handleButtonback(ActionEvent event) throws IOException{
    Stage stage;
    Parent root;
    
    stage = (Stage) btnClientMenu.getScene().getWindow();
    root = FXMLLoader.load(getClass().getResource("/uamexpress/UAMExpress.fxml"));
    
    Scene scene = new Scene(root);
    stage.setScene(scene);
    stage.show();
}

@FXML
public void handleAddClient(ActionEvent event){
    
    int id = Integer.parseInt(txtUserID.getText());
    String name = txtName.getText();
    String lastName = txtLastName.getText();
    int age = Integer.parseInt(txtAge.getText());
    String phone = txtPhone.getText();
    String email = txtEmail.getText();
    String address = txtAddress.getText();
    
    char gender;

    if (cmbGender.getValue() == "Female"){
        gender = 'f';
    }else{
        gender = 'm';
        
    client = new Client(id, name, lastName, age, phone, email, address, gender);
    operations.AddClient(client);
        
    }
}
    
    @FXML 
    public void handleSearch(ActionEvent event){
        
        
        String info;
        int id = Integer.parseInt(txt_clientID.getText());
        Iterator iter = operations.getClients().iterator();
        boolean bandera = true;
        
        while (iter.hasNext() && bandera==true){
            Client clients = (Client)iter.next();
            if (clients.getId() == id){
                info = "Informacion Cliente: " + 
                "\nId del cliente: " + clients.getId()+ "\n" + 
                "Nombre: " + clients.getName()+ "\n"+ 
                "Apellido: " + clients.getLastName()+ "\n"+
                "Genero: " + clients.getGender()+ "\n"+
                "Edad: " + clients.getAge()+ " Años\n" +
                "Telefono: " + clients.getPhone()+ "\n"+
                "Email: " + clients.getEmail()+ "\n"+ 
                "Direccion: " + clients.getAddress()+ "\n";
                JOptionPane.showMessageDialog(null,info );
                bandera = false;   
            }   
        }
        if(bandera){
            JOptionPane.showMessageDialog(null, "Cliente no encontrado", "Error",JOptionPane.ERROR_MESSAGE);
            }  
    }


//public void Search(){
//    String info;
//        int id = Integer.parseInt(txtUserID.getText());
//        Iterator iter = operations.getClients().iterator();
//        boolean bandera = true;
//        
//        while (iter.hasNext() && bandera==true){
//            if (client.getId() == id){
//                info = "Informacion Cliente: " + 
//                "\nId del cliente: " + client.getId()+ "\n" + 
//                "Nombre: " + client.getName()+ "\n"+ 
//                "Apellido: " + client.getLastName()+ "\n"+
//                "Genero: " + client.getGender()+ "\n"+
//                "Edad: " + client.getAge()+ " Años\n" +
//                "Telefono: " + client.getPhone()+ "\n"+
//                "Email: " + client.getEmail()+ "\n"+ 
//                "Direccion: " + client.getAddress()+ "\n";
//                JOptionPane.showMessageDialog(null,info );
//                bandera = false;   
//            }   
//        }
//        if(bandera){
//            JOptionPane.showMessageDialog(null, "Cliente no encontrado", "Error",JOptionPane.ERROR_MESSAGE);
//            }
//}

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
