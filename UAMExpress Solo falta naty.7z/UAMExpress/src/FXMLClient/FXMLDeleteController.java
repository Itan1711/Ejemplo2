
package FXMLClient;

import FXMLClient.Client;
import FXMLClient.ClientOperation;
import java.io.IOException;
import java.net.URL;
import java.util.Iterator;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javax.swing.JOptionPane;


public class FXMLDeleteController implements Initializable {
    
    @FXML private TextField txtClientID;
    @FXML private Button btnGoBack;
    ClientOperation operations = new ClientOperation();
    
    @FXML
    private void handleDelete(ActionEvent event) {
        
        int id = Integer.parseInt(txtClientID.getText());
        Iterator iter = operations.getClients().iterator();
        boolean delete = false;
        
        while (iter.hasNext() && delete == false){
            Client client = (Client)iter.next();
            if (client.getId()== id){
                operations.getClients().remove(client);
                delete = true;
            }   
        }
        
        if(delete != false){
            JOptionPane.showMessageDialog(null, "The selected employee has been deleted successfully", "Info",JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    @FXML
    public void handleButtonback(ActionEvent event) throws IOException{
    Stage stage;
    Parent root;
    
    stage = (Stage) btnGoBack.getScene().getWindow();
    root = FXMLLoader.load(getClass().getResource("/uamexpress/UAMExpress.fxml"));
    
    Scene scene = new Scene(root);
    stage.setScene(scene);
    stage.show();
}


    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }    
    
}
