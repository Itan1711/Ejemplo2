/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EmployeeSearch;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import java.util.Iterator;
import NewEmployee.*;
import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javax.swing.JOptionPane;
/**
 * FXML Controller class
 *
 * @author Natalya
 */
public class FXMLFindEmployeeController implements Initializable {

    @FXML private TextField txt_employeeID;
    EmployeeOperations operations = new EmployeeOperations();
    
    @FXML
    private void handleEmployeeSearch(ActionEvent event) {
        
        int id = Integer.parseInt(txt_employeeID.getText());
        boolean bandera1 = true;
        Iterator iter = operations.getEmployee().iterator();
        boolean bandera = true;
        
        while (iter.hasNext() && bandera==true){
            Employee newEmployee = (Employee)iter.next();
                if (newEmployee.GetId() == id){
                    String info = "Displaying the employee's information:\n " + 
                                   "\nId: " + newEmployee.GetId()+ "\n" + 
                                   "Name: " + newEmployee.GetNombre() + "\n"+ 
                                   "Last name: " + newEmployee.GetApellido() + "\n"+
                                   "Gender: " + newEmployee.GetGenero()+ "\n"+
                                   "Age: " + newEmployee.GetEdad()+ " Años\n" +
                                   "Phone number: " + newEmployee.GetTelefono()+ "\n"+
                                   "Email: " + newEmployee.GetEmail() + "\n"+ 
                                   "Address: " + newEmployee.GetDireccionFisica()+ "\n"+
                                   "Taxi plate ID: " + newEmployee.getTaxi().getPlaca() + "\n"+
                                   "GPS installed: " + newEmployee.getTaxi().getGps()+ "\n"+
                                   "Wheelchair transportation: " + newEmployee.getTaxi().getRampa_discapacitados() + "\n" +
                                   "Passenger capacity: " + newEmployee.getTaxi().getCantidad_pasajeros() + " pasajeros" + "\n" +
                                   "Employee since: " + newEmployee.GetDate();
                                    JOptionPane.showMessageDialog(null,info );
                                            bandera1=false;
                                         }
                                   }
                                    if (bandera1){
                                        JOptionPane.showMessageDialog(null, "Employee not found", "Error",JOptionPane.ERROR_MESSAGE);
                                    }
        
        
    }

        @FXML
        private Button btn_back;

        @FXML
        private void handleButtonAction(ActionEvent event) throws IOException{
            Stage stage;
            Parent root;
            stage=(Stage) btn_back.getScene().getWindow();   //aqui estoy diciendo que el boton cuando se presione, va a jalar una pantalla         
            root = FXMLLoader.load(getClass().getResource("/Employee/FXMLDocument.fxml"));

            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
