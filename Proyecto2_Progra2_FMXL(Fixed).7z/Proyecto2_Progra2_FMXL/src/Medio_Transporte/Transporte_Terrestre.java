
package Medio_Transporte;

/**
 *
 * @author Natalya
 */
public class Transporte_Terrestre {
    
    private String tipo;

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    public String Tipo_Transporte_Terrestre(String tipo){
        return "El tipo de transporte a utilizar serÃ­a: " + tipo;
    }
    
}


