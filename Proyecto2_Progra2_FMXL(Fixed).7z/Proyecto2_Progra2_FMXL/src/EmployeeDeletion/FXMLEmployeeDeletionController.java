/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EmployeeDeletion;

import NewEmployee.Employee;
import NewEmployee.EmployeeOperations;
import java.net.URL;
import java.util.Iterator;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author Natalya
 */
public class FXMLEmployeeDeletionController implements Initializable {

    @FXML private TextField txt_employeeID;
    EmployeeOperations operations = new EmployeeOperations();
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
     @FXML
    private void handleEmployeeDeletion(ActionEvent event) {
        
        int id = Integer.parseInt(txt_employeeID.getText());
        Iterator iter = operations.getEmployee().iterator();
        boolean delete = false;
        
        while (iter.hasNext() && delete == false){
            Employee newEmployee = (Employee)iter.next();
            if (newEmployee.GetId() == id){
                operations.getEmployee().remove(newEmployee);
                delete = true;
            }   
        }
        
        if(delete != false){
            JOptionPane.showMessageDialog(null, "The selected employee has been deleted successfully", "Info",JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    
    
    
    
    
}
