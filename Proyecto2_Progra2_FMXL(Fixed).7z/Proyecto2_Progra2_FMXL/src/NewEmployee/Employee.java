
package NewEmployee;

import Medio_Transporte.Taxi;
import java.util.Date;
import Persona.*;


public class Employee extends Persona {
    private Taxi taxi; //Aplicando la composicion
    Date date = new Date();
    
    public Employee(/*Date fecha*/int id, String name, String lastN,int age, String phone,
    String mail, String address, char gender, String plate, 
    int passengerCap, boolean gps, boolean rampa){
    this.SetId(id);
    this.SetNombre(name);
    this.SetApellido(lastN);
    this.SetEdad(age);
    this.SetTelefono(phone);
    this.SetEmail(mail);
    this.SetDireccionFisica(address);
    this.SetGenero(gender);
    this.taxi.setPlaca(plate);
    this.taxi.setCantidad_pasajeros(passengerCap); 
    this.taxi.setGps(gps);
    this.taxi.setRampa_discapacitados(rampa);
    //this.date = fecha;
    }
    
    public Employee(){}

    public Taxi getTaxi() {
        return taxi;
    }

    public void setTaxi(Taxi taxi) {
        this.taxi = taxi;
    }
    
    

    
    public String AtenderCliente(){
        return "El taxista esta atendiendo....";
    }
    
    public String CobrarTarifa(){
        return "El Taxista esta cobrando la tarifa";
    }
}

