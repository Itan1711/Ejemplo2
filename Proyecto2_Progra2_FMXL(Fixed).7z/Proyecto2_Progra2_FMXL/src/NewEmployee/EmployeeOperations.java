
package NewEmployee;

import java.util.ArrayList;


public class EmployeeOperations {
    
      private ArrayList<Employee> employee_List = new ArrayList<Employee>();

    public ArrayList<Employee> getEmployee() {
        return employee_List;
    }
    
    public boolean AddEmployee (Employee newEmployee){
        employee_List.add(newEmployee);
        return true;
    }
}
    
