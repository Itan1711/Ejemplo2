
package Employee;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import NewEmployee.*;
import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
/**
 *
 * @author Natalya
 */
public class FXMLEmployeeController implements Initializable {
    
    @FXML private TextField txt_UserID;
    @FXML private TextField txt_Name;
    @FXML private TextField txt_LastName;
    @FXML private TextField txt_Age;
    @FXML private TextField txt_Phone;
    @FXML private TextField txt_Email;
    @FXML private TextField txt_Address;
    @FXML private TextField txt_PlateNumber;
    @FXML private ComboBox cmb_Gender;
    @FXML private ComboBox cmb_Capacity;
    @FXML private ComboBox cmb_GPS;
    @FXML private ComboBox cmb_Wheelchair;    
    @FXML private Button btn_backMenu;
     
    Employee newEmployee;
    EmployeeOperations operations = new EmployeeOperations();
    
    @FXML
    private void handleAddEmployee(ActionEvent event) {
       
        int id = Integer.parseInt(txt_UserID.getText());
        String name = txt_Name.getText();
        String lastName = txt_LastName.getText();
        int age = Integer.parseInt(txt_Age.getText());
        String telephone = txt_Phone.getText();
        String email = txt_Email.getText();
        String address = txt_Address.getText();
        
        char gender;
        if(cmb_Gender.getValue() == "Female"){
            gender = 'f';
        } else {
            gender = 'm';
        }
        
        boolean gps;
        if(cmb_GPS.getValue() == "Yes"){
            gps = true;
        }else{
            gps = false;
        }
        
        int capacity = Integer.parseInt((String)cmb_Capacity.getValue());
 
        boolean wheelchair;
        if(cmb_Wheelchair.getValue() == "Yes"){
            wheelchair = true;
        }else{
            wheelchair = false;
        }
        
        String plate = txt_PlateNumber.getText();    
        
        
        
        newEmployee = new Employee(id, name, lastName, age, telephone, email, address, gender, plate, capacity,gps, wheelchair);
        operations.AddEmployee(newEmployee);  
    }
    
    
    @FXML
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("FXMLStudent.fxml"));
        
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
     @FXML
    private void handleBackMenu(ActionEvent backmenu) throws IOException{
        Stage stage;
        Parent root;
        
        backmenu.getSource();
        stage=(Stage) btn_backMenu.getScene().getWindow();
        root = FXMLLoader.load(getClass().getResource("/fxmluamexpress/FXMLmainMenu"));
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
