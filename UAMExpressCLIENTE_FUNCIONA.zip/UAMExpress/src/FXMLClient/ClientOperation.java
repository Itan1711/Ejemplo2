
package FXMLClient;

import java.util.ArrayList;


public class ClientOperation {
    
    private ArrayList<Client> clientlist = new ArrayList<>();
    
    private static ClientOperation instance = null;
    
    public ArrayList<Client> getClients(){
        return clientlist;
    }
    
    public boolean AddClient (Client client){
        clientlist.add(client);
        return true;
    }
    
    public static ClientOperation getIntance (){
        if(instance == null) {
         instance = new ClientOperation();
      }
      return instance;
    }
    
}
