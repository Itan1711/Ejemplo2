
package Client;

import java.util.ArrayList;


public class ClientOperation {
    private ArrayList<Client> clienteList = new ArrayList<Client>();
    
    public ArrayList<Client> getClients(){
        return clienteList;
    }
    
    public boolean AddClient (Client Client){
        clienteList.add(Client);
        return true;
    }
    
}
