
package FXMLCilent;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import Client.Client;
import Client.ClientOperation;

public class FXMLClientController implements Initializable {

    @FXML 
    private Button btnClientMenu;
    @FXML private TextField txtUserID;
    @FXML private TextField txtName;
    @FXML private TextField txtLastname;
    @FXML private TextField txtAge;
    @FXML private TextField txtPhone;
    @FXML private TextField txtEmail;
    @FXML private TextField txtAddress;
    @FXML private ComboBox cmbGender;
    @FXML private Button btnAddClient;
    
    Client client;
    ClientOperation operations = new ClientOperation();
    
    
    @FXML
    private void mainMenuAction(ActionEvent event) throws Exception{
        
        Stage stage;
        Parent root;
        
        if(event.getSource()==btnClientMenu){
        stage = (Stage) btnClientMenu.getScene().getWindow();
        root = FXMLLoader.load(getClass().getResource("/uamexpress/FXMLUAMExpress.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        }else{
            
            
        int id = Integer.parseInt(txtUserID.getText());
        String name = txtName.getText();
        String lastName = txtLastname.getText();
        int age = Integer.parseInt(txtAge.getText());
        String telephone = txtPhone.getText();
        String email = txtEmail.getText();
        String address = txtAddress.getText();
        
        char gender;
        if(cmbGender.getValue() == "Female"){
            gender = 'f';
        } else {
            gender = 'm';
        }
      
        client = new Client(id, name, lastName, gender, age, telephone, email, address, client.getDate());
        operations.AddClient(client);
        }
        
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
