
package uamexpress;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;


public class UAMExpressController implements Initializable {

@FXML private Button btnaddclient;
@FXML private Button btnsearch;
@FXML private Button btnDelete;
@FXML private Button btnBack;

public void handleAddClient(ActionEvent event) throws Exception{
    Stage stage;
    Parent root;
    
    if(event.getSource() == btnaddclient){
        stage=(Stage) btnaddclient.getScene().getWindow();            
        root = FXMLLoader.load(getClass().getResource("/FXMLClient/FXMLClient.fxml"));
    } else if (event.getSource() == btnsearch){
        stage=(Stage) btnsearch.getScene().getWindow();            
        root = FXMLLoader.load(getClass().getResource("/FXMLClient/FXMLSearch.fxml"));
    } else if(event.getSource() == btnDelete){
        stage=(Stage) btnDelete.getScene().getWindow();            
        root = FXMLLoader.load(getClass().getResource("/DeleteClient/FXMLDelete.fxml"));
    } else {
        stage=(Stage) btnBack.getScene().getWindow();            
        root = FXMLLoader.load(getClass().getResource("/MainMenu/FXMLMainMenu.fxml"));
    }
    
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
}

@Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    } 
}