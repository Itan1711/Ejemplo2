
package FXMLClient;

import java.io.*;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;


public class FXMLClientController implements Initializable {

@FXML private Button btnClientMenu;
@FXML private TextField txtUserID;
@FXML private TextField txtName;
@FXML private TextField txtLastName;
@FXML private TextField txtAge;
@FXML private TextField txtPhone;
@FXML private TextField txtEmail;
@FXML private TextField txtAddress;
@FXML private ComboBox cmbGender;
Client client;
public ClientOperation operations = new ClientOperation();

@FXML
public void handleButtonback(ActionEvent event) throws IOException{
    Stage stage;
    Parent root;
    
    stage = (Stage) btnClientMenu.getScene().getWindow();
    root = FXMLLoader.load(getClass().getResource("/uamexpress/UAMExpress.fxml"));
    
    Scene scene = new Scene(root);
    stage.setScene(scene);
    stage.show();
}

@FXML
public void handleAddClient(ActionEvent event){
    
    int id = Integer.parseInt(txtUserID.getText());
    String name = txtName.getText();
    String lastName = txtLastName.getText();
    int age = Integer.parseInt(txtAge.getText());
    String phone = txtPhone.getText();
    String email = txtEmail.getText();
    String address = txtAddress.getText();
    
    char gender;
    
    if (cmbGender.getValue() == "Female"){
        gender = 'f';
    }else{
        gender = 'm';
        
    client = new Client(id, name, lastName, age, phone, email, address, gender);
    operations.AddClient(client);
        
    }
}

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
