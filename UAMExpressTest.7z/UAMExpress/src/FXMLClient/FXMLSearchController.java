
package FXMLClient;

import java.io.IOException;
import java.net.URL;
import java.util.Iterator;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javax.swing.JOptionPane;


public class FXMLSearchController implements Initializable {
    @FXML private Button btnGoBack;
    @FXML private TextField txtClientID;
    ClientOperation operation = new ClientOperation();

    @FXML 
    public void handleSearch(ActionEvent event){
        String info;
        int id = Integer.parseInt(txtClientID.getText());
        Iterator iter = operation.getClients().iterator();
        boolean bandera = true;
        
        while (iter.hasNext() && bandera==true){
            Client client = (Client)iter.next();
            if (client.getId() == id){
                info = "Informacion Cliente: " + 
                "\nId del cliente: " + client.getId()+ "\n" + 
                "Nombre: " + client.getName()+ "\n"+ 
                "Apellido: " + client.getLastName()+ "\n"+
                "Genero: " + client.getGender()+ "\n"+
                "Edad: " + client.getAge()+ " Años\n" +
                "Telefono: " + client.getPhone()+ "\n"+
                "Email: " + client.getEmail()+ "\n"+ 
                "Direccion: " + client.getAddress()+ "\n";
                JOptionPane.showMessageDialog(null,info );
                bandera = false;   
            }   
        }
        if(bandera){
            JOptionPane.showMessageDialog(null, "Cliente no encontrado", "Error",JOptionPane.ERROR_MESSAGE);
            }
    }
    
    @FXML
    public void handleButtonback(ActionEvent event) throws IOException{
    Stage stage;
    Parent root;
    
    stage = (Stage) btnGoBack.getScene().getWindow();
    root = FXMLLoader.load(getClass().getResource("/uamexpress/UAMExpress.fxml"));
    
    Scene scene = new Scene(root);
    stage.setScene(scene);
    stage.show();
}
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }    
    
}
