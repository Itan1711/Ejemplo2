
package FXMLClient;

import java.util.ArrayList;


public class ClientOperation {
    
    public ArrayList<Client> clientlist = new ArrayList<>();
    
    public ArrayList<Client> getClients(){
        return clientlist;
    }
    
    public boolean AddClient (Client client){
        clientlist.add(client);
        return true;
    }
}
